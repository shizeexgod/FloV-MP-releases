<# : FloV:MP server setup and update for Windows. Double-click to run.
@echo off
setlocal
chcp 65001 >nul
title FloV:MP - server setup and update
set "FLOVMP_SETUP_SELF=%~f0"
set "FLOVMP_SETUP_ARGS=%*"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$t = [IO.File]::ReadAllText($env:FLOVMP_SETUP_SELF, [Text.Encoding]::UTF8); & ([ScriptBlock]::Create($t))"
set "RC=%ERRORLEVEL%"
echo.
pause
exit /b %RC%
#>
# =====================================================================================
#  FloV:MP — установка и обновление сервера (Windows). Двойной щелчок по этому файлу.
#
#  Первый запуск — установка: скрипт спросит папку сервера и ключ лицензии.
#  Следующие запуски — обновление: найденный сервер обновляется, ключ берётся из него.
#
#  В этом файле нет ни ключей, ни самого сервера, ни загрузчика: загрузчик выдаётся
#  сервером раздачи только по действующему ключу лицензии, по HTTPS, и перед запуском
#  проверяется подписью релизов FloV:MP (открытый ключ — ниже). Пакет сервера загрузчик
#  тоже проверяет подписью и SHA-256. Ключ хранится только в папке установленного
#  сервера (config\flovmp.env) — этот файл и архив его не запоминают.
#
#  Без вопросов (для планировщика): FloVMP-Setup.cmd -InstallDir "C:\FloVMP-Server" -Quiet
#  Параметры: -InstallDir <папка> -Key <ключ> -Product runtime|source|both -Reinstall -Quiet
# =====================================================================================
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Dist = 'https://lic.flovmp.ru'
# BEGIN RELEASE_PUBKEY_XML
$ReleasePubKeyXml = '<RSAKeyValue><Modulus>pmynUrPAKz17KYFCg3URy5BgBanGtIDxbLIExHQ59tdxAcUN2uPMN7Wu51TSkvit5kKxZvDWF9MSll2sLCXUJMpX9Lxa1GFLpmx6axrrw44z4id0ESrb1C7kqyOYu54lBVdBVyCup09Kgyfrc1vE9J7LRTUD+9DaahJ1CVkcg4uopbBItVqywb4UuOlbGuAf1x/ocgO3hrKv9e6R+LN33EH3udfMlEcq7GWVN5/GW0709KWF21zemEm4wS3NRUWnAGvwBcwgOIQdKoybjZtMgY6rpKCganSdpcGthunHnAOddbPSoerR6imGgqL2zTzKMFsPpxxOz1Mop3MdqkDbM5g2laOt8CyfcTwYgQi2OUf7K3MmXqkR1sv8duIlRRW1GOEaMg7M2zvm4MwVe4qMIms7ME+fREEIAE4UmdP8v5Pc8fhEQNl5WD2eTXY57DC08IrRE0GbwAg1R99C9Du3mtDfUsL1Uo+uwzLny0LnQuhILpMotkDPe7arcMbsSVQp</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
# END RELEASE_PUBKEY_XML

function Fail([string]$Text) {
    Write-Host ''
    Write-Host "ОШИБКА: $Text" -ForegroundColor Red
    Write-Host 'Установка не выполнена. Папка сервера не изменена.' -ForegroundColor Red
    exit 1
}
if ($ReleasePubKeyXml.Length -lt 100) { Fail 'файл установки повреждён — скачайте архив установки заново' }

# --- параметры командной строки ------------------------------------------------------
$opt = @{ InstallDir = ''; Key = ''; Product = ''; Reinstall = $false; Quiet = $false }
$tokens = @([regex]::Matches([string]$env:FLOVMP_SETUP_ARGS, '"[^"]*"|\S+') | ForEach-Object { $_.Value.Trim('"') })
for ($i = 0; $i -lt $tokens.Count; $i++) {
    $name = $tokens[$i].TrimStart('-', '/').ToLowerInvariant()
    $next = if ($i + 1 -lt $tokens.Count) { $tokens[$i + 1] } else { '' }
    switch ($name) {
        'installdir' { $opt.InstallDir = $next; $i++ }
        'key'        { $opt.Key = $next; $i++ }
        'product'    { $opt.Product = $next.ToLowerInvariant(); $i++ }
        'reinstall'  { $opt.Reinstall = $true }
        'quiet'      { $opt.Quiet = $true }
        default      { Fail "неизвестный параметр: $($tokens[$i]). Список — в ИНСТРУКЦИЯ.txt" }
    }
}
if ($opt.Product -and $opt.Product -notin @('runtime', 'source', 'both')) { Fail '-Product: runtime, source или both' }
$interactive = -not $opt.Quiet -and [Environment]::UserInteractive

Write-Host ''
Write-Host '  FloV:MP — установка и обновление сервера' -ForegroundColor Cyan
Write-Host '  ----------------------------------------' -ForegroundColor Cyan

# --- где стоят серверы ---------------------------------------------------------------
# Только пути (без ключей): %LOCALAPPDATA%\FloVMP\server-setup.json.
$stateDir = Join-Path $env:LOCALAPPDATA 'FloVMP'
$statePath = Join-Path $stateDir 'server-setup.json'
function Test-Installed([string]$Dir) {
    $Dir -and ((Test-Path -LiteralPath (Join-Path $Dir 'manifest.json')) -or (Test-Path -LiteralPath (Join-Path $Dir 'flovmp-install.json')))
}
function Get-InstalledVersion([string]$Dir) {
    try { return [string](Get-Content -LiteralPath (Join-Path $Dir 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version } catch { return '' }
}
$known = @()
if (Test-Path -LiteralPath $statePath) {
    try { $known = @((Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json).servers | ForEach-Object { [string]$_ }) } catch { $known = @() }
}
$known = @($known | Where-Object { Test-Installed $_ } | Select-Object -Unique)

function Read-Folder {
    $default = Join-Path $env:SystemDrive 'FloVMP-Server'
    Write-Host ''
    Write-Host '  Куда поставить сервер? Лучше отдельная папка, не Рабочий стол и не Загрузки.'
    Write-Host "  Enter — $default, либо введите свой путь."
    $answer = (Read-Host '  Папка сервера').Trim().Trim('"')
    if ($answer) { return $answer } else { return $default }
}

$dir = $opt.InstallDir
if (-not $dir) {
    if ($known.Count -gt 0 -and $interactive) {
        Write-Host ''
        Write-Host '  Найдены установленные серверы FloV:MP:'
        for ($n = 0; $n -lt $known.Count; $n++) {
            $v = Get-InstalledVersion $known[$n]
            Write-Host ("   {0}) обновить {1}{2}" -f ($n + 1), $known[$n], $(if ($v) { " (сейчас $v)" } else { '' }))
        }
        $newChoice = $known.Count + 1
        Write-Host "   $newChoice) поставить ещё один сервер в другую папку"
        do {
            $answer = (Read-Host "  Выберите 1-$newChoice [1]").Trim()
            if (-not $answer) { $answer = '1' }
            $pick = 0
            [void][int]::TryParse($answer, [ref]$pick)
        } while ($pick -lt 1 -or $pick -gt $newChoice)
        $dir = if ($pick -eq $newChoice) { Read-Folder } else { $known[$pick - 1] }
    }
    elseif ($known.Count -gt 0) { $dir = $known[0] }
    elseif ($interactive) { $dir = Read-Folder }
    else { Fail 'не указана папка сервера: -InstallDir "C:\FloVMP-Server"' }
}

try { $dir = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($dir)).TrimEnd([IO.Path]::DirectorySeparatorChar) }
catch { Fail "неверный путь: $dir" }
if ($dir.Length -le 3) { Fail "в корень диска ставить нельзя: $dir — укажите папку, например C:\FloVMP-Server" }
$update = Test-Installed $dir
# Новую установку — только в отдельную папку. Уже установленный сервер обновляем там,
# где он стоит (старый архив установки распаковывали прямо в папку сервера).
if (-not $update) {
    $here = Split-Path -Parent ([string]$env:FLOVMP_SETUP_SELF)
    $forbidden = @($env:ProgramData, $env:USERPROFILE, $env:LOCALAPPDATA, $env:APPDATA, [Environment]::GetFolderPath('Desktop'),
        [Environment]::GetFolderPath('MyDocuments'), (Join-Path $env:USERPROFILE 'Downloads'), $here)
    foreach ($f in $forbidden) {
        if ($f -and $dir.Equals($f.TrimEnd([IO.Path]::DirectorySeparatorChar), [StringComparison]::OrdinalIgnoreCase)) {
            Fail "в эту папку ставить нельзя: $dir — нужна отдельная папка, например $(Join-Path $env:SystemDrive 'FloVMP-Server')"
        }
    }
}
$sep = [IO.Path]::DirectorySeparatorChar
foreach ($f in @($env:SystemRoot, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
    if (-not $f) { continue }
    $f = $f.TrimEnd($sep)
    if ($dir.Equals($f, [StringComparison]::OrdinalIgnoreCase) -or $dir.StartsWith($f + $sep, [StringComparison]::OrdinalIgnoreCase)) {
        Fail "в системную папку ставить нельзя: $dir"
    }
}
if (-not $update -and (Test-Path -LiteralPath $dir) -and @(Get-ChildItem -LiteralPath $dir -Force -ErrorAction SilentlyContinue | Select-Object -First 1).Count -gt 0) {
    Write-Host ''
    Write-Host "  Внимание: папка $dir не пустая, и сервера FloV:MP в ней нет." -ForegroundColor Yellow
    Write-Host '  Ваши файлы не удаляются, но лучше ставить в пустую папку.' -ForegroundColor Yellow
    if ($interactive -and (Read-Host '  Продолжить? (д/н) [н]').Trim().ToLowerInvariant() -notin @('д', 'да', 'y', 'yes')) { Fail 'отменено' }
}
Write-Host ''
if ($update) {
    $v = Get-InstalledVersion $dir
    Write-Host "  Обновление сервера: $dir$(if ($v) { " (сейчас $v)" })" -ForegroundColor Cyan
} else {
    Write-Host "  Новая установка: $dir" -ForegroundColor Cyan
}

# --- ключ лицензии -------------------------------------------------------------------
$key = $opt.Key
if (-not $key -and $update) {
    $envPath = Join-Path (Join-Path $dir 'config') 'flovmp.env'
    if (Test-Path -LiteralPath $envPath) {
        foreach ($line in Get-Content -LiteralPath $envPath -Encoding UTF8) {
            if ($line -match '^\s*FLOVMP_LICENSE_KEY\s*=\s*(\S+)') { $key = $Matches[1] }
        }
    }
    if (-not $key) {
        # Только исходники (Source Kit): ключ лежит в flovmp-install.json.
        try { $key = [string](Get-Content -LiteralPath (Join-Path $dir 'flovmp-install.json') -Raw -Encoding UTF8 | ConvertFrom-Json).key } catch { }
    }
    if ($key) { Write-Host '  ключ лицензии — из установленного сервера' }
}
if (-not $key -and $interactive) {
    Write-Host ''
    Write-Host '  Ключ лицензии выдаётся при покупке и выглядит так:'
    Write-Host '  FLV-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX' -ForegroundColor DarkGray
    $key = Read-Host '  Ключ лицензии'
}
$key = ([string]$key).Trim().ToUpperInvariant() -replace '[^A-Z0-9-]', ''
if (-not $key) { Fail 'без ключа лицензии установить нельзя' }
if ($key -notmatch '^FLV(-[0-9A-F]{8}){4}$') { Fail 'это не похоже на ключ лицензии FloV:MP (вид: FLV-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX)' }

# --- загрузчик: по ключу, по HTTPS, с проверкой подписи ------------------------------
function Get-Signed([string]$Path) {
    $request = [Net.HttpWebRequest]::Create("$Dist$Path")
    $request.Timeout = 60000
    $request.ReadWriteTimeout = 60000
    $request.UserAgent = 'FloVMP-Setup'
    $request.AllowAutoRedirect = $false   # ключ уходит только на сервер раздачи FloV:MP
    $request.Headers.Add('X-FloV-Key', $key)
    $response = $null
    try {
        try { $response = $request.GetResponse() }
        catch [Net.WebException] {
            $r = $_.Exception.Response
            if (-not $r) {
                Fail "нет связи с сервером раздачи ($Dist): $($_.Exception.Message). Проверьте интернет и повторите"
            }
            $code = [int]$r.StatusCode
            $reason = ''
            try {
                $body = (New-Object IO.StreamReader($r.GetResponseStream(), [Text.Encoding]::UTF8)).ReadToEnd()
                $reason = [string]($body | ConvertFrom-Json).reason
            } catch { }
            $r.Close()
            switch ($code) {
                403 { Fail "ключ не принят: $reason" }
                429 { Fail "сервер раздачи: $reason" }
                404 { Fail 'сервер раздачи пока не выдаёт установщик этим способом — повторите позже' }
                default { Fail "сервер раздачи ответил $code $reason" }
            }
        }
        if ([int]$response.StatusCode -ne 200) { Fail "сервер раздачи ответил $([int]$response.StatusCode)" }
        $buffer = New-Object IO.MemoryStream
        $response.GetResponseStream().CopyTo($buffer)
        return ,$buffer.ToArray()
    }
    finally { if ($response) { $response.Close() } }
}

Write-Host ''
Write-Host '  получаю установщик с сервера раздачи'
$loaderBytes = Get-Signed '/api/v1/distribution/loader?os=windows'
$signatureText = [Text.Encoding]::ASCII.GetString((Get-Signed '/api/v1/distribution/loader.sig?os=windows')).Trim()
try { $signature = [Convert]::FromBase64String($signatureText) } catch { Fail 'повреждённая подпись установщика' }
$rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
try {
    $rsa.FromXmlString($ReleasePubKeyXml)
    $valid = $rsa.VerifyData($loaderBytes, [Security.Cryptography.CryptoConfig]::MapNameToOID('SHA256'), $signature)
} finally { $rsa.Dispose() }
if (-not $valid) { Fail 'подпись установщика НЕ верна — он подменён. Ничего не запущено' }
Write-Host '  подпись установщика верна' -ForegroundColor Green
$loaderText = [Text.Encoding]::UTF8.GetString($loaderBytes)
if ($loaderText.Length -gt 0 -and $loaderText[0] -eq [char]0xFEFF) { $loaderText = $loaderText.Substring(1) }

# --- остатки установщика 1.0.17 и раньше ----------------------------------------------
# Старый архив распаковывался прямо в папку сервера, а «настройки.txt» хранил ключ
# открытым текстом рядом с ним. Убираем только свои файлы, узнавая их по содержимому.
if ($update) {
    $old = @{
        'настройки.txt'      = '# Настройки установки FloV:MP'
        'flovmp-setup.ps1'   = 'FloV:MP — установка и обновление в один клик'
        'get.ps1'            = 'FloV:MP — установка и обновление сервера одной командой'
        'УСТАНОВИТЬ.cmd'     = 'flovmp-setup.ps1'
        'КАК-УСТАНОВИТЬ.md'  = 'FloV:MP'
        'ПРОЧТИ-МЕНЯ.txt'    = 'FloV:MP'
    }
    $removed = @()
    foreach ($name in $old.Keys) {
        $path = Join-Path $dir $name
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        try {
            if ((Get-Content -LiteralPath $path -Raw -Encoding UTF8).Contains($old[$name])) {
                Remove-Item -LiteralPath $path -Force
                $removed += $name
            }
        } catch { }
    }
    if ($removed.Count) { Write-Host "  убраны файлы старого установщика: $($removed -join ', ')" -ForegroundColor DarkGray }
}

# --- установка: всё остальное делает проверенный загрузчик ----------------------------
$arguments = @{ Key = $key; InstallDir = $dir; Dist = $Dist }
if ($opt.Product) { $arguments.Product = $opt.Product }
if ($opt.Reinstall) { $arguments.Reinstall = $true }
if ($opt.Quiet) { $arguments.Quiet = $true }
Write-Host ''
try { & ([ScriptBlock]::Create($loaderText)) @arguments }
catch { Fail $_.Exception.Message }

# Запомнить папку (без ключа) — следующий запуск сразу предложит обновить её.
try {
    New-Item -ItemType Directory -Path $stateDir -Force | Out-Null
    $list = @($dir) + @($known | Where-Object { -not $_.Equals($dir, [StringComparison]::OrdinalIgnoreCase) })
    [IO.File]::WriteAllText($statePath, (@{ servers = $list } | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
} catch { }

$installed = 'runtime'
try { $installed = [string](Get-Content -LiteralPath (Join-Path $dir 'flovmp-install.json') -Raw -Encoding UTF8 | ConvertFrom-Json).product } catch { }
Write-Host ''
Write-Host '  Готово.' -ForegroundColor Green
if ($installed -ne 'source') {
    Write-Host "  - запуск сервера: $dir\FloVMP-Server.exe"
    Write-Host "  - настройки: $dir\server\server.toml"
}
Write-Host '  - обновление: запустите FloVMP-Setup.cmd ещё раз'
Write-Host '  - ключ лицензии хранится только в папке сервера (config\flovmp.env) — никому её не пересылайте'

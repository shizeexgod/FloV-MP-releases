﻿param(
    [string]$Key = '',
    [string]$InstallDir = '',
    [string]$Dist = '',
    [string]$GitHub = '',
    [string]$Tag = '',
    [ValidateSet('', 'runtime', 'source', 'both')]
    [string]$Product = '',
    [string]$SourceDir = '',
    [switch]$Force,
    [switch]$NoStart,
    [switch]$Reinstall,
    [switch]$Quiet
)
# FloV:MP — установка и обновление сервера одной командой (Windows).
#
#   cd C:\Мой сервер
#   powershell -ExecutionPolicy Bypass -Command "iwr http://<адрес>/cdn/get.ps1 -OutFile get.ps1; .\get.ps1 -Key FLV-XXXX-XXXX-XXXX-XXXX"
#
# Без -InstallDir ставит в текущую папку (ту, куда клиент зашёл через cd).
# Повторный запуск в той же папке — обновление: ключ и настройки берутся из
# уже установленного config\flovmp.env, свои файлы клиента не трогаются.
#
# По ключу лицензии получает описание последнего релиза, проверяет его подпись
# ключом релизов FloV:MP (вшит ниже), скачивает ZIP-пакет, сверяет SHA-256 и
# запускает установщик из пакета (install.ps1). Подмена пакета не пройдёт.
#
# Тариф Source Kit: сервер лицензий сообщает, что ключу доступен исходный код,
# и установщик предлагает выбор (запоминается в flovmp-install.json):
#   runtime — готовый сервер (как в License);
#   source  — исходный код FloV:MP;
#   both    — готовый сервер + исходный код (исходники — в подпапке source).
# Без вопросов: -Product runtime|source|both [-SourceDir <папка исходников>].
# Исходники берутся только с сервера раздачи по ключу (не с GitHub), их описание
# подписано тем же ключом релизов. При обновлении исходников ваши правки не
# затираются: изменённый вами и нами файл остаётся вашим, новая версия — рядом
# (<файл>.flovmp-new).
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue' # иначе Invoke-WebRequest качает в разы медленнее

# Сервер раздачи — по имени (30.09.2026 VDS сменил IP; прежний адрес не используем).
# Имя не разрешается (DNS ещё не обновился) — запасной IP.
if (-not $Dist) { $Dist = if ($env:FLOVMP_DIST_URL) { $env:FLOVMP_DIST_URL } else { 'http://lic.flovmp.ru' } }
if ($Dist -match '188\.127\.229\.224') { $Dist = 'http://lic.flovmp.ru' }
$Dist = $Dist.TrimEnd('/')
if ($Dist -eq 'http://lic.flovmp.ru') {
    try { [void][System.Net.Dns]::GetHostAddresses('lic.flovmp.ru') } catch { $Dist = 'http://188.130.132.82' }
}
# -GitHub owner/repo — брать готовый сервер из GitHub, а не с сервера раздачи.
# Подпись проверяется та же самая, поэтому подменить пакет на GitHub тоже нельзя.
# Без -Tag берётся последний стабильный релиз; с -Tag — именно он (например
# бета: -Tag v1.0.5-beta). Так у клиентов остаётся стабильная версия, а
# владелец может поставить бету одной и той же командой.
$GitHubBase = if ($GitHub) {
    $repo = $GitHub.Trim('/')
    if ($Tag) { "https://github.com/$repo/releases/download/$($Tag.Trim())" }
    else { "https://github.com/$repo/releases/latest/download" }
} else { '' }

# BEGIN RELEASE_PUBKEY_XML
$ReleasePubKeyXml = '<RSAKeyValue><Modulus>pmynUrPAKz17KYFCg3URy5BgBanGtIDxbLIExHQ59tdxAcUN2uPMN7Wu51TSkvit5kKxZvDWF9MSll2sLCXUJMpX9Lxa1GFLpmx6axrrw44z4id0ESrb1C7kqyOYu54lBVdBVyCup09Kgyfrc1vE9J7LRTUD+9DaahJ1CVkcg4uopbBItVqywb4UuOlbGuAf1x/ocgO3hrKv9e6R+LN33EH3udfMlEcq7GWVN5/GW0709KWF21zemEm4wS3NRUWnAGvwBcwgOIQdKoybjZtMgY6rpKCganSdpcGthunHnAOddbPSoerR6imGgqL2zTzKMFsPpxxOz1Mop3MdqkDbM5g2laOt8CyfcTwYgQi2OUf7K3MmXqkR1sv8duIlRRW1GOEaMg7M2zvm4MwVe4qMIms7ME+fREEIAE4UmdP8v5Pc8fhEQNl5WD2eTXY57DC08IrRE0GbwAg1R99C9Du3mtDfUsL1Uo+uwzLny0LnQuhILpMotkDPe7arcMbsSVQp</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
# END RELEASE_PUBKEY_XML

function Fail($t) { Write-Host "ОШИБКА: $t" -ForegroundColor Red; exit 1 }
if (-not $ReleasePubKeyXml) { Fail 'в загрузчике нет ключа релизов — скачайте get.ps1 заново' }

# Куда ставим: по умолчанию — текущая папка (клиент зашёл в неё через cd).
if (-not $InstallDir) { $InstallDir = (Get-Location).ProviderPath }
$target = [IO.Path]::GetFullPath($InstallDir).TrimEnd([IO.Path]::DirectorySeparatorChar)
foreach ($forbidden in @($env:SystemRoot, (Join-Path $env:SystemRoot 'System32'), $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:USERPROFILE)) {
    if ($forbidden -and $target.TrimEnd('\').Equals($forbidden.TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) {
        Fail "в системную папку ставить нельзя: $target. Зайдите в папку сервера (cd) или укажите -InstallDir"
    }
}
Write-Host "Папка установки: $target" -ForegroundColor Cyan

# Обновление: ключ уже лежит рядом, второй раз его вводить не нужно.
$envPath = Join-Path $target 'config\flovmp.env'
$choicePath = Join-Path $target 'flovmp-install.json'
$installedVersion = ''
if (Test-Path -LiteralPath (Join-Path $target 'manifest.json')) {
    try { $installedVersion = (Get-Content -LiteralPath (Join-Path $target 'manifest.json') -Raw | ConvertFrom-Json).version } catch { }
}
$saved = $null
if (Test-Path -LiteralPath $choicePath) {
    try { $saved = Get-Content -LiteralPath $choicePath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $saved = $null }
}
if (-not $Key -and (Test-Path -LiteralPath $envPath)) {
    foreach ($line in Get-Content -LiteralPath $envPath -Encoding UTF8) {
        if ($line -match '^\s*FLOVMP_LICENSE_KEY\s*=\s*(\S+)') { $Key = $Matches[1] }
    }
    if ($Key) { Write-Host '  ключ лицензии взят из установленного config\flovmp.env' }
}
if (-not $Key -and $saved -and $saved.key) {
    $Key = [string]$saved.key
    Write-Host '  ключ лицензии взят из flovmp-install.json'
}
# Ключ не передан и не сохранён — спрашиваем: сначала ключ, потом файлы (без ключа ничего не качается).
if (-not $Key -and -not $Quiet -and [Environment]::UserInteractive) {
    Write-Host ''
    Write-Host '  Введите ключ лицензии FloV:MP (выдаётся при покупке, вид FLV-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX).'
    $Key = (Read-Host '  Ключ').Trim()
}
if (-not $Key) { Fail 'нужен ключ лицензии: -Key FLV-XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX' }

$cleanKey = ($Key.Trim().ToUpperInvariant() -replace '[^A-Z0-9-]', '')
if ($cleanKey -notmatch '^FLV(-[0-9A-F]{8}){4}$') { Fail "ключ не похож на лицензионный: $cleanKey" }
$q = "os=windows&key=$cleanKey"

$work = Join-Path ([IO.Path]::GetTempPath()) ('flovmp-get-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work -Force | Out-Null
try {
    function Fetch([string]$Url, [string]$Out) {
        try { Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Out -TimeoutSec 600 }
        catch {
            $msg = $_.Exception.Message
            try { $msg = (New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())).ReadToEnd() } catch { }
            if (-not $msg -and $_.ErrorDetails -and $_.ErrorDetails.Message) { $msg = $_.ErrorDetails.Message }
            Fail "сервер раздачи: $msg"
        }
    }

    # Пакет — десятки мегабайт, а у части провайдеров длинные загрузки
    # обрываются. Докачиваем с места обрыва (HTTP Range: GitHub и nginx раздачи
    # его поддерживают); сервер без Range — качаем целиком заново.
    # Invoke-WebRequest в Windows PowerShell 5.1 докачивать не умеет.
    function Download([string]$Url, [string]$Out) {
        if (Test-Path -LiteralPath $Out) { Remove-Item -LiteralPath $Out -Force }
        $resume = $true
        for ($try = 1; $try -le 8; $try++) {
            $have = if (Test-Path -LiteralPath $Out) { (Get-Item -LiteralPath $Out).Length } else { 0 }
            $response = $null
            try {
                $request = [Net.HttpWebRequest]::Create($Url)
                $request.Timeout = 30000
                $request.ReadWriteTimeout = 60000
                $request.UserAgent = 'FloVMP-get'
                if ($resume -and $have -gt 0) { $request.AddRange([long]$have) }
                try { $response = $request.GetResponse() }
                catch [Net.WebException] {
                    $r = $_.Exception.Response
                    if ($r) {
                        $code = [int]$r.StatusCode
                        $body = ''
                        try { $body = (New-Object IO.StreamReader($r.GetResponseStream())).ReadToEnd() } catch { }
                        $r.Close()
                        if ($code -eq 416) { return }   # уже скачан целиком — проверит SHA-256
                        if ($code -ge 400) { Fail "$Url ответил $code $body" }
                    }
                    throw
                }
                $append = $have -gt 0 -and [int]$response.StatusCode -eq 206
                if ($have -gt 0 -and -not $append -and $resume) {
                    Write-Host '  сервер не поддерживает докачку — качаю пакет заново' -ForegroundColor Yellow
                    $resume = $false
                }
                $mode = if ($append) { [IO.FileMode]::Append } else { [IO.FileMode]::Create }
                $before = if ($append) { $have } else { 0 }
                $expected = $response.ContentLength
                $file = New-Object IO.FileStream($Out, $mode, [IO.FileAccess]::Write)
                try { $response.GetResponseStream().CopyTo($file) } finally { $file.Dispose(); $response.Close() }
                $got = (Get-Item -LiteralPath $Out).Length - $before
                if ($expected -ge 0 -and $got -lt $expected) { throw 'поток закрылся раньше конца файла' }
                return
            }
            catch {
                if ($response) { $response.Close() }
                $mb = if (Test-Path -LiteralPath $Out) { [math]::Floor((Get-Item -LiteralPath $Out).Length / 1MB) } else { 0 }
                Write-Host "  связь оборвалась на $mb МБ — докачиваю (попытка $($try + 1) из 8)" -ForegroundColor Yellow
                Start-Sleep -Seconds ($try * 2)
            }
        }
        Fail "не удалось скачать ${Url}: связь рвётся. Повторите позже"
    }

    # Описание релиза: подпись ключом релизов FloV:MP — иначе установка останавливается.
    function Read-SignedRelease([string]$Url, [string]$SigUrl, [string]$Name) {
        $file = Join-Path $work "$Name.txt"
        Fetch $Url $file
        Fetch $SigUrl "$file.sig"
        $bytes = [IO.File]::ReadAllBytes($file)
        $sig = [Convert]::FromBase64String(([IO.File]::ReadAllText("$file.sig")).Trim())
        $rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
        $rsa.FromXmlString($ReleasePubKeyXml)
        if (-not $rsa.VerifyData($bytes, [Security.Cryptography.CryptoConfig]::MapNameToOID('SHA256'), $sig)) {
            Fail 'подпись релиза НЕ верна — описание подменено. Установка остановлена'
        }
        $info = @{}
        foreach ($line in [Text.Encoding]::UTF8.GetString($bytes) -split "`n") {
            $i = $line.IndexOf('='); if ($i -gt 0) { $info[$line.Substring(0, $i)] = $line.Substring($i + 1).Trim() }
        }
        return $info
    }

    # --- что доступно ключу ------------------------------------------------------------
    # Меню установщика: тариф Source Kit даёт выбор. Сервер раздачи старой версии
    # этого адреса не знает — тогда ставим готовый сервер, как раньше.
    $products = $null
    try {
        $resp = Invoke-WebRequest -UseBasicParsing -Uri "$Dist/api/v1/distribution/products?key=$cleanKey" -TimeoutSec 60
        $products = [Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray()) | ConvertFrom-Json
    }
    catch {
        $code = 0
        $body = ''
        if ($_.Exception.Response) {
            $code = [int]$_.Exception.Response.StatusCode
            try { $body = (New-Object IO.StreamReader($_.Exception.Response.GetResponseStream())).ReadToEnd() } catch { }
        }
        # Windows PowerShell 5.1 уже прочитал поток ответа — тело ошибки лежит в ErrorDetails.
        if (-not $body -and $_.ErrorDetails -and $_.ErrorDetails.Message) { $body = $_.ErrorDetails.Message }
        if ($code -eq 403 -or $code -eq 429) {
            $reason = $body
            try { $reason = ($body | ConvertFrom-Json).reason } catch { }
            Fail "сервер раздачи: $reason"
        }
        if ($Product -in @('source', 'both')) { Fail "сервер раздачи не ответил, доступны ли исходники: $($_.Exception.Message)" }
        Write-Host '  сервер раздачи не сообщил тариф — ставлю готовый сервер' -ForegroundColor Yellow
    }
    $sourceAllowed = [bool]($products -and $products.source)
    if ($products) {
        Write-Host "  тариф: $($products.product)$(if ($products.project) { " · проект $($products.project)" })"
    }

    # --- выбор: готовый сервер, исходники или оба ---------------------------------------
    $remembered = if ($saved -and $saved.product -in @('runtime', 'source', 'both')) { [string]$saved.product } else { '' }
    if ($Product) {
        if ($Product -ne 'runtime' -and -not $sourceAllowed) {
            Fail "исходный код доступен только в тарифе Source Kit. Ваш тариф: $(if ($products) { $products.product } else { 'License' })"
        }
    }
    elseif ($remembered -and ($remembered -eq 'runtime' -or $sourceAllowed)) {
        $Product = $remembered
        Write-Host "  состав установки: $Product (из flovmp-install.json)"
    }
    elseif ($sourceAllowed -and -not $Quiet -and [Environment]::UserInteractive) {
        $sourceHint = if ($SourceDir) { $SourceDir } elseif (Test-Path -LiteralPath (Join-Path $target 'manifest.txt')) { Join-Path $target 'source' } else { $target }
        Write-Host ''
        Write-Host '  Ваш тариф — Source Kit: доступен и исходный код FloV:MP.' -ForegroundColor Cyan
        Write-Host '  Что установить?'
        Write-Host "   1) Готовый сервер — в $target"
        Write-Host "   2) Исходный код — в $sourceHint"
        Write-Host "   3) Готовый сервер и исходный код (исходники — в $(Join-Path $target 'source'))"
        do {
            $answer = (Read-Host '  Выберите 1, 2 или 3 [3]').Trim()
            if (-not $answer) { $answer = '3' }
        } while ($answer -notin @('1', '2', '3'))
        $Product = @{ '1' = 'runtime'; '2' = 'source'; '3' = 'both' }[$answer]
    }
    else {
        $Product = 'runtime'
        if ($sourceAllowed) { Write-Host '  исходный код тоже доступен: -Product source или -Product both' -ForegroundColor DarkGray }
    }

    if (-not $SourceDir -and $saved -and $saved.sourceDir -and $Product -ne 'runtime') { $SourceDir = [string]$saved.sourceDir }
    if (-not $SourceDir) {
        $SourceDir = if ($Product -eq 'source' -and -not (Test-Path -LiteralPath (Join-Path $target 'manifest.txt'))) { $target } else { Join-Path $target 'source' }
    }
    $SourceDir = [IO.Path]::GetFullPath($SourceDir).TrimEnd('\')

    # --- готовый сервер -------------------------------------------------------------------
    function Install-Runtime {
        Write-Host '==> Готовый сервер FloV:MP' -ForegroundColor Cyan
        if ($GitHubBase) {
            $info = Read-SignedRelease "$GitHubBase/release-windows.txt" "$GitHubBase/release-windows.txt.sig" 'release'
        } else {
            $info = Read-SignedRelease "$Dist/api/v1/distribution/release?$q" "$Dist/api/v1/distribution/release.sig?$q" 'release'
        }
        Write-Host '  подпись релиза верна' -ForegroundColor Green
        if ($info.os -ne 'windows') { Fail "релиз не для Windows ($($info.os))" }
        if ($info.file -notmatch '^[A-Za-z0-9._-]+\.zip$') { Fail "неверное имя пакета: $($info.file)" }
        if ($info.sha256 -notmatch '^[0-9a-f]{64}$') { Fail 'неверный SHA-256 в релизе' }
        Write-Host "  версия $($info.version), пакет $($info.file)"

        if ($installedVersion) {
            Write-Host "  установлено сейчас: $installedVersion"
            if ($installedVersion -eq $info.version -and -not $Reinstall) {
                Write-Host '  обновление не требуется: установлена та же версия (повторить установку — -Reinstall)' -ForegroundColor Green
                return
            }
        }

        Write-Host '  скачивание пакета'
        $zip = Join-Path $work $info.file
        if ($GitHubBase) { Download "$GitHubBase/$($info.file)" $zip }
        else { Download "$Dist/api/v1/distribution/download?$q" $zip }
        $got = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($got -ne $info.sha256) { Fail "SHA-256 пакета не совпал (ожидали $($info.sha256), получили $got)" }
        Write-Host '  SHA-256 совпал' -ForegroundColor Green

        $unpack = Join-Path $work 'package'
        Expand-Archive -LiteralPath $zip -DestinationPath $unpack -Force
        $roots = @(Get-ChildItem -LiteralPath $unpack -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'manifest.txt') })
        if ($roots.Count -ne 1) { Fail 'в пакете должен быть ровно один каталог с manifest.txt' }
        $installer = Join-Path $roots[0].FullName 'install.ps1'
        if (-not (Test-Path -LiteralPath $installer)) { Fail 'в пакете нет install.ps1' }

        Write-Host '  установка'
        $arguments = @{ InstallDir = $target; LicenseKey = $cleanKey }
        if ($Force) { $arguments.Force = $true }
        if ($NoStart) { $arguments.NoStart = $true }
        try { & $installer @arguments }
        catch {
            # Установщик бросает понятное сообщение (столкновение файлов, нет места,
            # файл занят). Клиенту нужна причина, а не трассировка PowerShell.
            Fail $_.Exception.Message
        }
    }

    # --- исходный код (Source Kit) --------------------------------------------------------
    # Python 3.8+: им накладывается обновление исходников (ваши правки не затираются),
    # и он же нужен для сборки пакетов из исходников (scripts/pack_server.py).
    function Find-Python {
        foreach ($candidate in @(@('py', '-3'), @('python'), @('python3'))) {
            $exe = $candidate[0]
            if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { continue }
            $pre = @($candidate | Select-Object -Skip 1)
            try {
                $ok = & $exe @pre -c 'import sys; print(sys.version_info >= (3, 8))' 2>$null
                if ($LASTEXITCODE -eq 0 -and "$ok".Trim() -eq 'True') { return ,$candidate }
            } catch { }
        }
        return $null
    }

    function Install-Source {
        Write-Host '==> Исходный код FloV:MP (Source Kit)' -ForegroundColor Cyan
        $sq = "product=source&key=$cleanKey"
        $info = Read-SignedRelease "$Dist/api/v1/distribution/release?$sq" "$Dist/api/v1/distribution/release.sig?$sq" 'release-source'
        Write-Host '  подпись исходников верна' -ForegroundColor Green
        if ($info.product -ne 'flovmp-source' -or $info.os -ne 'all') { Fail 'описание не относится к исходникам FloV:MP' }
        if ($info.file -notmatch '^flovmp-source-[A-Za-z0-9._-]+\.zip$') { Fail "неверное имя архива исходников: $($info.file)" }
        if ($info.sha256 -notmatch '^[0-9a-f]{64}$') { Fail 'неверный SHA-256 исходников' }
        Write-Host "  версия $($info.version) → $SourceDir"

        $currentManifest = Join-Path $SourceDir 'SOURCE-MANIFEST.json'
        if ((Test-Path -LiteralPath $currentManifest) -and -not $Reinstall) {
            try {
                $current = (Get-Content -LiteralPath $currentManifest -Raw -Encoding UTF8 | ConvertFrom-Json).version
                if ($current -eq $info.version) {
                    Write-Host '  исходники уже этой версии (повторить — -Reinstall)' -ForegroundColor Green
                    return
                }
                Write-Host "  установлены исходники $current"
            } catch { }
        }

        $zip = Join-Path $work $info.file
        Download "$Dist/api/v1/distribution/download?$sq" $zip
        $got = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($got -ne $info.sha256) { Fail "SHA-256 исходников не совпал (ожидали $($info.sha256), получили $got)" }
        Write-Host '  SHA-256 совпал' -ForegroundColor Green

        $unpack = Join-Path $work 'source'
        Expand-Archive -LiteralPath $zip -DestinationPath $unpack -Force
        $roots = @(Get-ChildItem -LiteralPath $unpack -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'SOURCE-MANIFEST.json') })
        if ($roots.Count -ne 1) { Fail 'в архиве исходников должен быть ровно один каталог с SOURCE-MANIFEST.json' }
        $root = $roots[0].FullName
        if ((Test-Path -LiteralPath (Join-Path $SourceDir 'manifest.txt')) -and (Test-Path -LiteralPath (Join-Path $SourceDir 'delivery.json'))) {
            Fail "в $SourceDir установлен готовый сервер — исходники ставьте в отдельную папку (-SourceDir)"
        }
        New-Item -ItemType Directory -Path $SourceDir -Force | Out-Null

        $python = Find-Python
        if ($python) {
            # Проверка каждого файла и обновление с сохранением ваших правок — scripts/flo_update.py
            # из только что проверенного архива (его версия совпадает с исходниками).
            $updater = Join-Path $root 'scripts\flo_update.py'
            if (-not (Test-Path -LiteralPath $updater)) { Fail 'в исходниках нет scripts\flo_update.py' }
            $exe = $python[0]
            $pre = @($python | Select-Object -Skip 1)
            $env:PYTHONIOENCODING = 'utf-8'
            & $exe @pre $updater --product source-kit --root $SourceDir --package $zip --sha256 $info.sha256
            if ($LASTEXITCODE -ne 0) { Fail 'исходники не установлены (подробности выше) — папка оставлена как была' }
            return
        }

        # Без Python — только первая установка в пустую папку: проверяем каждый файл по
        # SOURCE-MANIFEST.json и копируем. Обновление поверх ваших правок требует Python.
        $existing = @(Get-ChildItem -LiteralPath $SourceDir -Force | Select-Object -First 1)
        if ($existing.Count -gt 0) {
            Fail ('для обновления исходников нужен Python 3.8+ (он сохраняет ваши правки). ' +
                  'Установите: winget install Python.Python.3.12 — и запустите установку ещё раз')
        }
        $manifest = Get-Content -LiteralPath (Join-Path $root 'SOURCE-MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($manifest.deliveryMode -ne 'source-kit') { Fail 'архив не является Source Kit' }
        foreach ($entry in $manifest.files) {
            $rel = [string]$entry.path
            if ($rel -match '(^|[\\/])\.\.([\\/]|$)' -or [IO.Path]::IsPathRooted($rel) -or $rel.Contains(':')) { Fail "небезопасный путь в исходниках: $rel" }
            $src = Join-Path $root $rel
            if (-not (Test-Path -LiteralPath $src -PathType Leaf)) { Fail "в архиве нет файла $rel" }
            $hash = (Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($hash -ne ([string]$entry.sha256).ToLowerInvariant()) { Fail "SHA-256 не совпал: $rel" }
        }
        Copy-Item -Path (Join-Path $root '*') -Destination $SourceDir -Recurse -Force
        Write-Host "  исходники $($info.version) установлены: $($manifest.files.Count) файлов" -ForegroundColor Green
        Write-Host '  для обновлений и сборки поставьте Python 3.8+: winget install Python.Python.3.12' -ForegroundColor Yellow
    }

    if ($Product -in @('runtime', 'both')) { Install-Runtime }
    if ($Product -in @('source', 'both')) { Install-Source }

    # Выбор запоминается: обновление — тот же запуск без параметров.
    $choice = [ordered]@{ product = $Product }
    if ($Product -ne 'runtime') { $choice.sourceDir = $SourceDir }
    if ($Product -eq 'source') { $choice.key = $cleanKey }   # готового сервера нет — ключ больше негде взять
    New-Item -ItemType Directory -Path $target -Force | Out-Null
    [IO.File]::WriteAllText($choicePath, ($choice | ConvertTo-Json), [Text.UTF8Encoding]::new($false))

    Write-Host ''
    if ($Product -in @('runtime', 'both')) { Write-Host "Готовый сервер: $target" -ForegroundColor Green }
    if ($Product -in @('source', 'both')) {
        Write-Host "Исходный код:   $SourceDir" -ForegroundColor Green
        Write-Host '  с чего начать — README.md и DELIVERY-MODES.md в папке исходников'
    }
} finally {
    Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
}
